package Interfaz;

import javax.swing.JPanel;

public class fondoRegistro extends JPanel {

	/**
	 * Create the panel.
	 */
	public fondoRegistro() {

	}

}
